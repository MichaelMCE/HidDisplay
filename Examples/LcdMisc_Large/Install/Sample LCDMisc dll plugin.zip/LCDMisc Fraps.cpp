#include <Windows.h>
#include <Psapi.h>

#include "DllTypes.h"

struct FrapsData {
	DWORD SizeOfStruct;
	DWORD CurrentFPS;
	DWORD TotalFrames;
	DWORD TimeOfLastFrame;
	char GameName[32];
	int unknown[4];
	int width;
	int height;
	int unknown2;
};

typedef FrapsData * WINAPI  FrapsSharedDataProc();
FrapsSharedDataProc *FrapsSharedData = 0;
HMODULE hFraps = 0;

BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD fdwReason, void* lpvReserved) {
	if (fdwReason == DLL_PROCESS_DETACH) {
		if (hFraps) {
			FreeLibrary(hFraps);
			hFraps = 0;
			FrapsSharedData = 0;
		}
	}
	return 1;
}

void CALLBACK Init(AppInfo *in, DllInfo *out) {
	if (in->size < sizeof(AppInfo) || in->maxDllVersion < 1 || out->size < sizeof(DllInfo)) return;
	out->free = free;
	out->dllVersion = 1;
}

void CALLBACK GetFrapsData(ScriptVal *in, ScriptVal *out) {
	if (!hFraps) {
		HWND hWnd;
		hWnd = GetForegroundWindow();
		if (!hWnd) return;
		DWORD id = -1, temp=0;
		if (GetWindowThreadProcessId(hWnd, &id)) {
			HANDLE h = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, 0, id);
			HMODULE modules[10000];
			int res = EnumProcessModules(h, modules, 10000, &temp);
			if (res) {
				temp/=sizeof(HMODULE);
				unsigned int i;
				wchar_t name[1500];
				for (i=0; i<temp; i++) {
					res = GetModuleFileNameExW(h, modules[i], name, 1500);
					if (res) {
						wchar_t *fname = 0;
						for (int j=0; name[j]; j++) {
							if (name[j] == '\\') fname = name+j+1;
						}
// Note:  Not a standard definition.  (No WIN64...It's still WIN32).
#ifdef X64
						if (wcsicmp(fname, L"fraps64.dll") == 0) {
#else
						if (wcsicmp(fname, L"fraps.dll") == 0) {
#endif
							hFraps = LoadLibraryW(name);
							if (hFraps) {
								FrapsSharedData = (FrapsSharedDataProc*) GetProcAddress(hFraps, "FrapsSharedData");
								if (FrapsSharedData) {
									break;
								}
								FreeLibrary(hFraps);
								hFraps = 0;
							}
						}
					}
				}
			}
			CloseHandle(h);
			if (!hFraps) return;
		}
	}
	if (!FrapsSharedData) {
		FrapsSharedData = (FrapsSharedDataProc*) GetProcAddress(hFraps, "FrapsSharedData");
		if (!FrapsSharedData) return;
	}
	FrapsData *fsd = FrapsSharedData();
	if (fsd && fsd->SizeOfStruct >= 48) {
		ScriptVal sv, sv2;
		MakeDictValue(out);

		MakeStaticStringValue(&sv, "fps");
		MakeIntValue(&sv2, fsd->CurrentFPS);
		out->dictValue.Add(&sv, &sv2);

		MakeStaticStringValue(&sv, "frame");
		MakeIntValue(&sv2, fsd->TotalFrames);
		out->dictValue.Add(&sv, &sv2);

		MakeStaticStringValue(&sv, "lastframe");
		MakeIntValue(&sv2, fsd->TimeOfLastFrame);
		out->dictValue.Add(&sv, &sv2);

		if (fsd->SizeOfStruct >= sizeof(*fsd)) {
			MakeStaticStringValue(&sv, "width");
			MakeIntValue(&sv2, fsd->width);
			out->dictValue.Add(&sv, &sv2);

			MakeStaticStringValue(&sv, "height");
			MakeIntValue(&sv2, fsd->height);
			out->dictValue.Add(&sv, &sv2);

			MakeStaticStringValue(&sv, "unknown1");
			MakeIntValue(&sv2, fsd->unknown[0]);
			out->dictValue.Add(&sv, &sv2);

			MakeStaticStringValue(&sv, "unknown2");
			MakeIntValue(&sv2, fsd->unknown2);
			out->dictValue.Add(&sv, &sv2);
		}

		MakeStaticStringValue(&sv, "name");
		int len = 0;
		char name[33];
		while (fsd->GameName[len] && len < 31) {
			name[len] = fsd->GameName[len];
			len++;
		}
		name[len] = 0;
		MakeStringValue(&sv2, name);
		out->dictValue.Add(&sv, &sv2);
	}
}
