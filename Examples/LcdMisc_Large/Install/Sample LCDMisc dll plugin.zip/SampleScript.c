dll32 Fraps "LCDMisc Fraps32.dll" "Init";
dll64 Fraps "LCDMisc Fraps64.dll" "Init";
dll Fraps function GetFraps "GetFrapsData";
